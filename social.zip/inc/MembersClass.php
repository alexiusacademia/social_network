<?php

	class Member
	{

		/***************/
		/*	Properties */
		/***************/
		private $p_username;

		/************/
		/*	Methods */
		/************/
		public function getUsername($user_id){
			
		}
	}

?>