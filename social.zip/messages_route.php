<?php

	if(!isset($_SESSION['uname_log'])){
		// The user is not logged in
		header("location: index.php");
	}else{
		
	}



?>