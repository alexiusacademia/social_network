SIMPLE STATS 1.10
=================


DISCLAIMER

    *  We, at USER STUDIO, are not responsible for any damage that may be caused to your website from any proper or improper use of our products. By installing our products, you agree to use them at your own risks!
    * In addition, we don't guaranty that our products will serve their purpose properly, as stated on their information sites such as this one.


COPYRIGHT

    *  Simple Stats is distributed for free by USER STUDIO under the BSD License. Don't hesitate to spread the word!
    *  Simple Publisher, however, is the property of USER STUDIO, even when installed on a third party website. The property rights apply to the product itself, name, web domain, code, interaction principles and graphics. USER STUDIO is not responsible for the third party content that may be published using Simple Publisher.
    *  USER STUDIO on the web: http://en.userstudio.fr/
    
    
FOR MORE INFORMATION

    *  Browse to the following address: http://stats.simplepublisher.com/
    *  The code mainly dates back to 2011, but since its flat file approach is popular we keep it out here for your pleasure.
